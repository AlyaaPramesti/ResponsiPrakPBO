/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;
import responsi.DBConnect;
import responsi.HomeView;
/**
 *
 * @author ROG
 */
public class Main {
        public static void main(String[] args) {
        // TODO code application logic here
        DBConnect coba = new DBConnect();
        new HomeView().show();
    }
}
