/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;
import javax.swing.JOptionPane;
import responsi.InputModel;
import responsi.HomeView;
/**
 *
 * @author ROG
 */
public class OutputController {
        public void prosesdaftar(String nama, String usia, String gaji) {
        InputModel daftar = new InputModel();
        daftar.insertdaftar( nama, usia, gaji);
        String INFO_MESSAGE = "Berhasil";
        JOptionPane.showMessageDialog(null,INFO_MESSAGE);
        //
        this.kembali();
    }
        public void kembali(){
        new HomeView().show();
    } 
}
