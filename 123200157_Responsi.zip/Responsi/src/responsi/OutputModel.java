/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

import javax.swing.JOptionPane;
import responsi.DBConnect;
/**
 *
 * @author ROG
 */
public class OutputModel {
  public void update(String id, String nama, String usia, String gaji) {
        DBConnect konek = new DBConnect();
        try {
            konek.statement = konek.koneksi.createStatement();
            konek.statement.executeUpdate("UPDATE data set " 
            + "nama     ='"     + nama + "', "
            + "usia     ='"     + usia + "', "
            + "gaji     ='"     + gaji + "'  "       
            + "WHERE id ='"     +  id  +   "'");
        
        } catch (Exception e) {
        e.printStackTrace();
      }
    }

    //methode delete
    public void delete(String id) {
         DBConnect konek = new DBConnect();
        int jawab;
        try {
            if ((jawab = JOptionPane.showConfirmDialog(null, "Ingin menghapus data?", "konfirmasi", JOptionPane.YES_NO_OPTION)) == 0) {
                konek.statement = konek.koneksi.createStatement();
                konek.statement.executeUpdate("DELETE FROM karyawan WHERE id ='" +id+ "'");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //methode simpan
    public void simpan(String nama, String usia, String gaji) {
        DBConnect konek = new DBConnect();
        try {
            String query = "INSERT INTO `karyawan`(`nama`, `usia`,'gaji')"
                           +" VALUES ('"+nama+"','"+usia+"','"+gaji+"')";
            konek.statement = konek.koneksi.createStatement();
            konek.statement.executeUpdate(query);
        
        } catch (Exception e) {
        e.printStackTrace();
      }
    }  
}
