/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

import javax.swing.JOptionPane;
import responsi.DBConnect;

/**
 *
 * @author ROG
 */
public class InputModel {
   public void insertdaftar(String nama, String usia, String gaji) {
        DBConnect konek = new DBConnect();
        
        try{
            String query = "INSERT INTO `karyawan`(`nama`, `usia`,`gaji`) VALUES ('"+nama+"','"+usia+"','"+gaji+"')";        
            konek.statement = konek.koneksi.createStatement();
            konek.statement.executeUpdate(query);
        }
        catch (java.sql.SQLException e){
        }
    }      
}
